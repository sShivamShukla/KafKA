package com.okta.javakafka.kafkajava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
